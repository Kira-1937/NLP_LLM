import streamlit as st

def app():
    st.subheader('Pondering is a website created for users to')
    st.subheader('share their valuable thoughts with the world.')
    st.markdown('Created by: [Ankit](https://github.com/ak1484)')
    st.markdown('Contact via mail: [ankitsaharan1484@gmail.com]')
    