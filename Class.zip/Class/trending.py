import streamlit as st

def app():
    st.subheader('Trending thoughts')

    st.text_area(label='#',value='Please wait this page is under construction..')
    